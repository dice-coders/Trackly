from sqlalchemy.orm import Session
from sqlalchemy import select
from models.chat_model import ChatHistory
class ChatHistoryRepository:
    def __init__(self, db: Session) :
        self.db = db
        
    def save_chat(self, chat: ChatHistory) :
        self.db.add(chat)
        self.db.commit()
        self.db.refresh(chat)
    
    def get_history(self) -> list :
        return self.db.execute(
            select(ChatHistory)
        ).scalars().all()