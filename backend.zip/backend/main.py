from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers.goal_router import router as goal_router
from routers.user_router import router as user_router
from routers.lead_router import router as lead_router
from routers.dashboard_router import router as dashboard_router
from routers.chat_router import router as chat_router
from routers.auth_router import router as auth_router
from database import Base, engine

Base.metadata.create_all(bind=engine)

app = FastAPI()

app.include_router(goal_router)
app.include_router(user_router)
app.include_router(lead_router)
app.include_router(dashboard_router)
app.include_router(chat_router)
app.include_router(auth_router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Em produção, coloque o domínio real
    allow_methods=["*"],
    allow_headers=["*"],
)
